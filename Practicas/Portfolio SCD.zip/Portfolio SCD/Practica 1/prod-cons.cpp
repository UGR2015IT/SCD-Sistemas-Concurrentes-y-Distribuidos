/*
====================================================
		PRODUCTOR-CONSUMIDOR
====================================================
En este codigo vamos a inicializar dos indices (index_prod por el productor y index_cons por el consumidor) que determinen en que posicion se puede escribir (productor) o leer (consumidor). Tambien hay un array por guardar los datos producidos, y un contador para calcular el dato producido.
Los semaforos utilizados son 3: mutex por la exclusion mutua, para que no hay problemas de lectura/escritura en el mismo tiempo, y puede_leer y puede_escribir para que los corrispondentes procesos de consumidor/productor esperen o hacen su funcion.
Cuando un productor quiere escribir su valor producido en el array, espera por dos semaforos (mutex y puede_escribir). Desbloqueados estos, puede escribir, en posicion index_pos, el valor que ha producido. Luego, vuelve a desbloquear el proceso consumidor, que ahora puede leer sin problemas de exclusion mutua.
Sigue el codigo fuente completo.
*/

#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

using namespace std;

const unsigned
    tam_vector = 10,
    max_iter=50,
    num_hebras=10;

int myVector[tam_vector], i = 0, contador = 0, index_prod = 0 , index_cons=0;

sem_t mutex, puede_leer, puede_escribir;

void rand_usleep(){
    unsigned miliseg = 100U + (rand() % 1900U) ;
    usleep( 1000U*miliseg );
}

// ---------------------------------------------------------------------
unsigned producir_dato() {
    rand_usleep();
    cout << "dato producido: " << contador << endl << flush ;
    return contador++ ;
}
// ---------------------------------------------------------------------
void consumir_dato( int dato ) {
    rand_usleep();
    cout << "dato recibido: " << dato << endl ;
}
// ---------------------------------------------------------------------

void* producir(void * ){

    int dato = producir_dato() ;

    sem_wait(&puede_escribir);
    sem_wait(&mutex);
    myVector[index_prod] = dato;
    index_prod++;
    sem_post(&mutex);
    sem_post(&puede_leer);

}

void* consumir(void*){
    int dato;

    sem_wait(&puede_leer);
    sem_wait(&mutex);
    dato = myVector[index_cons];
    index_cons++;
    sem_post(&puede_escribir);
    sem_post(&mutex);

    cout << "index value: " << index_cons <<endl;
    consumir_dato( dato ) ;
}

int main(){

    srand( time(NULL));

    sem_init(&mutex, 0, 1);
    sem_init(&puede_leer,0,0);
    sem_init(&puede_escribir,0,1);

    pthread_t hebra_prod[num_hebras], hebra_cons[num_hebras];

    for (i=0;i<num_hebras;i++){
        pthread_create(&hebra_prod[i], NULL, producir, NULL);
        pthread_create(&hebra_cons[i], NULL, consumir, NULL);
    }

    for (i=0;i<num_hebras;i++){
        pthread_join(hebra_prod[i], NULL);
        pthread_join(hebra_cons[i], NULL);
    }

    pthread_exit(NULL);

    sem_destroy(&puede_leer);
    sem_destroy(&puede_escribir);
    sem_destroy(&mutex);

    return 0;
}
