/*
===============================================
		LOS 3 FUMADORES
===============================================
En esto codigo vamos a utilizar 4 semafores, 3 en un array por los fumadores, y uno por el estanquero.
El semaforo por fumador se usan por indicar cuando un fumador puede recoger su ingrediente de la mesa: el estanquero hace un signal una vez que el ingrediente necesario por un fumador està en la mesa, y este signal desbloquea dicho fumador que està esperando por un wait. Una vez recogido, hace un signal al estanquero para que pueda poner un nuevo ingrediente en la mesa para que un nuevo fumador pueda empiezar su accion.
Los semaforos de los fumadores son inicializados a 0 (a todos falta un ingrediente), mientras el del estanquero a 1(puede poner un ingrediente aleatorio en la mesa).
Sigue el codigo fuente completo.
===============================================
*/

#include <iostream>
#include <cassert>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>      // incluye "time(....)"
#include <unistd.h>    // incluye "usleep(...)"
#include <stdlib.h>    // incluye "rand(...)" y "srand"

using namespace std;

// ============================================================================
// Constant sections

const static int n_fumadores = 3,
                    n_hebras = 10;

sem_t sem_fumador[3], sem_estanquero;

// ============================================================================
// función que simula la acción de fumar  como un retardo aleatorio de la hebra

void fumar() {
   //  inicializa la semilla aleatoria  (solo la primera vez)
   static bool primera_vez = true ;
   if ( primera_vez )
   {   primera_vez = false ;
      srand( time(NULL) );    
   }
   
   // calcular un numero aleatorio de milisegundos (entre 1/10 y 2 segundos)
   const unsigned miliseg = 100U + (rand() % 1900U) ; 

   // retraso bloqueado durante 'miliseg' milisegundos
   usleep( 1000U*miliseg ); 
}
// ============================================================================

// Function section

void* fumadores(void* n_fum){
    while (true){
        sem_wait(&sem_fumador[(unsigned long)n_fum]);
        sem_post(&sem_estanquero);
        cout << "The smoker n°"<<((unsigned long)n_fum )+1<< " is smoking."<<endl;
        fumar();
        cout << "The smoker n°"<<((unsigned long)n_fum )+1<< " is done smoking."<<endl;
    }
}

void* estanquero(void*p){
    while (true){
        sem_wait(&sem_estanquero);
        unsigned int index_fumador = (rand() % n_fumadores);
        sem_post(&sem_fumador[index_fumador]);
    }

}

// ============================================================================

int main()
{

    for (int i=0; i<n_fumadores;i++){
        sem_init(&sem_fumador[i] , 0 , 0);
    }
    sem_init(&sem_estanquero, 0, 1);

    pthread_t hebra_fumador[n_fumadores], hebra_estanquero;

    cout << "Initialized semaphores & hebras" << endl;

    for (int i=0;i<n_fumadores;i++){
        cout << "Created the smoker n°"<<i+1<<endl;
        pthread_create(&(hebra_fumador[i]), NULL, fumadores, (void*) i);
    }
    pthread_create (&hebra_estanquero, NULL, estanquero, NULL);

    cout << "Created the hebras and executed them" <<endl;

    for (int i=0;i<n_fumadores;i++)
        pthread_join(hebra_fumador[i], NULL);
    pthread_join(hebra_estanquero, NULL);

    cout << "Joined the hebras, almost done."<<endl;

    pthread_exit(NULL);

    for (int i=0;i<n_fumadores;i++)
        sem_destroy(&sem_fumador[i]);
    sem_destroy(&sem_estanquero);
    
    return 0 ;
}
